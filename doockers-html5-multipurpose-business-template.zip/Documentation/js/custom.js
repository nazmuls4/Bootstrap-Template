//$(function() {
//
//  $('#sb-skin-light').on('click', function() {
//    $('.sidebar-boxed').removeClass('sidebar-dark');
//  });
//
//  $('#sb-skin-dark').on('click', function() {
//    $('.sidebar-boxed').addClass('sidebar-dark');
//  });
//
//});

