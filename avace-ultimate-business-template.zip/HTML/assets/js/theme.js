(function ($) {
    "use strict";
    $(document).ready(function () {

        $('.switcher').css('display', 'none');
    });
})(jQuery);