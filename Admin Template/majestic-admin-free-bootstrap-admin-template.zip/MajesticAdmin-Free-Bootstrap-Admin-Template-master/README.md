# MajesticAdmin-Free-Bootstrap-Admin-Template

Majestic Admin is a free bootstrap responsive admin template with an elegant design and well structured code.

<h2>Demo</h2>

[![N|Solid](preview.png)](http://www.urbanui.com/majestic/template/index.html)
